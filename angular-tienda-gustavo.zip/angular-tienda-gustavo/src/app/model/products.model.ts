import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';

@Injectable()
export class ProductsModel{
  public data : any = [
    {
      p_id : '1',
      product_name : 'aguacate',
      product_weight : '1ml',
      product_price : '100',
      product_image : 'https://image.freepik.com/foto-gratis/aguacate-aislado-blanco_62856-4854.jpg'
    },
    {
      p_id : '2',
      product_name : 'ajo',
      product_weight : '2ml',
      product_price : '110',
      product_image : 'https://img2.freepng.es/20180531/bgs/kisspng-garlic-peeler-organic-food-health-vegetable-5b0fb190701f82.3540698215277551524593.jpg'
    },
    {
      p_id : '3',
      product_name : 'almendras',
      product_weight : '3ml',
      product_price : '120',
      product_image : 'https://img2.freepng.es/20190429/zap/kisspng-almond-portable-network-graphics-clip-art-transpar-5cc73de4ed7329.6398535815565613809726.jpg'
    },
    {
      p_id : '4',
      product_name : 'arandanos',
      product_weight : '4ml',
      product_price : '130',
      product_image : 'https://img2.freepng.es/20190612/ggf/kisspng-blueberry-tea-huckleberry-bilberry-juniper-berry-5d009291838065.8947609915603186095386.jpg'
    },
    {
      p_id : '5',
      product_name : 'brocoli',
      product_weight : '5ml',
      product_price : '140',
      product_image : 'https://www.seekpng.com/png/detail/94-942738_imagenes-png-de-brocoli.png'
    },
    {
      p_id : '6',
      product_name : 'calabaza',
      product_weight : '6ml',
      product_price : '150',
      product_image : 'https://i0.pngocean.com/files/1004/920/17/pumpkin-de-snelle-vegetarier-verrukkelijke-recepten-in-een-handomdraai-cucurbita-maxima-red-curry-cucurbita-pepo-pumpkin.jpg'
    },
    {
      p_id : '7',
      product_name : 'canela',
      product_weight : '7ml',
      product_price : '160',
      product_image : 'https://img.pngio.com/canela-png-3-png-image-canela-png-900_700.png'
    },
    {
      p_id : '8',
      product_name : 'cebolla',
      product_weight : '8ml',
      product_price : '170',
      product_image : 
      'https://img2.freepng.es/20180130/jlw/kisspng-red-onion-shallot-beefsteak-vegetable-onion-5a704c2cc57038.6565387715173089728087.jpg'
    },
    {
      p_id : '9',
      product_name : 'fresa',
      product_weight : '9ml',
      product_price : '180',
      product_image : 'https://img2.freepng.es/20181110/ssk/kisspng-strawberry-pie-strawberry-juice-portable-network-g-fruits-et-lgumes-5be6a53ec1c779.3247892715418422387937.jpg'
    },
    {
      p_id : '10',
      product_name : 'kiwi',
      product_weight : '10ml',
      product_price : '190',
      product_image : 'https://i.pinimg.com/originals/61/c2/26/61c22661bef5b5358c9b8fa4049947aa.png'
    },
    {
      p_id : '11',
      product_name : 'limon',
      product_weight : '11ml',
      product_price : '200',
      product_image : 'https://www.seekpng.com/png/detail/380-3800805_lima-limon-y-sal-png.png'
    },
    {
      p_id : '12',
      product_name : 'lychee',
      product_weight : '12ml',
      product_price : '210',
      product_image : 'https://www.pngitem.com/pimgs/m/58-587952_lychee-png-transparent-png.png'
    },
    {
      p_id : '13',
      product_name : 'maiz',
      product_weight : '13ml',
      product_price : '220',
      product_image : 'https://img2.freepng.es/20190715/oqg/kisspng-corn-on-the-cob-maize-clip-art-portable-network-gr-5d2c86469000d2.5139948515631990465898.jpg'
    },
    {
      p_id : '14',
      product_name : 'manzana',
      product_weight : '14ml',
      product_price : '230',
      product_image : 'https://img2.freepng.es/20180207/spe/kisspng-apple-juice-apple-juice-fruit-apple-fruit-5a7b37901cd6b1.2391217315180245921181.jpg'
    },
    {
      p_id : '15',
      product_name : 'naranja',
      product_weight : '15ml',
      product_price : '240',
      product_image : 'https://image.shutterstock.com/image-photo/half-slice-fresh-orange-fruit-260nw-1012447147.jpg'
    },
    {
      p_id : '16',
      product_name : 'papa',
      product_weight : '16ml',
      product_price : '250',
      product_image : 'https://img2.freepng.es/20180520/xva/kisspng-sweet-potato-root-vegetables-tuber-5b0136da4469b2.8520494315268062342802.jpg'
    },
    {
      p_id : '17',
      product_name : 'pasta',
      product_weight : '17ml',
      product_price : '260',
      product_image : 'https://i.dlpng.com/static/png/1752964-pasta-png-pasta-png-800_512_preview.png'
    },
    {
      p_id : '18',
      product_name : 'pimienta',
      product_weight : '18ml',
      product_price : '270',
      product_image : 'https://i0.pngocean.com/files/759/18/397/5bd83f5cecf63.jpg'
    },
    {
      p_id : '19',
      product_name : 'repollo',
      product_weight : '20ml',
      product_price : '280',
      product_image : 'https://previews.123rf.com/images/ginosphotos/ginosphotos1110/ginosphotos111000022/10763915-cabeza-de-repollo-aislado-sobre-fondo-blanco.jpg'
    },
    {
      p_id : '20',
      product_name : 'tomate',
      product_weight : '21ml',
      product_price : '290',
      product_image : 'https://www.masscience.com/wp-content/uploads/2015/11/tomates.jpg'
    },
    {
      p_id : '21',
      product_name : 'zanahoria',
      product_weight : '22ml',
      product_price : '300',
      product_image : 'https://www.gob.mx/cms/uploads/image/file/318296/zanahoria1.jpg'
    
    }
  ]
}