import { Injectable } from '@angular/core';

@Injectable()
export class CompanyDetailsModel{
  
  public companyInfo : any = 
    {
      name : 'Tienda Gustavo',
      address : '110110',
      city: 'Bogota',
      pincode: '124578',
      email: 'gsordo@gmail.com',
      phone : '2457-54781447'
    }
    
  
} 