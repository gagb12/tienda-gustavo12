import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';
@Component({
  selector :'cart',
  template : `
  <div class="card text-center">
  <div class="card-header">
    Su carrito de artículos
    <button type="button" class="btn btn-sm btn-warning float-right">
        Total de articulos <span class="badge badge-light">{{cart.cartItemsList.length}}</span>        
    </button>
    <button type="button" class="btn btn-sm btn-danger mr-2 float-right" (click)="emptyCart()" *ngIf="cart.cartItemsList && cart.cartTotal">
       Carro Vacio      
    </button>
  </div>
  <div class="card-body">  
    <table class="table">
      <thead>
        <tr>      
          <th scope="col">Producto</th>
          <th scope="col">Precio</th>
          <th scope="col">Peso</th>
          <th scope="col">Total</th>
        </tr>
      </thead>
      <tbody>
        <tr>
        
        </tr>
        <tr *ngFor="let itm of cart.cartItemsList ">      
          <td class="text-left">{{itm.name}}</td>
          <td>{{itm.price/itm.qty}} x</td>
          <td class="w30">
            <div class="input-group input-group-sm mb-3">
              <div class="input-group-prepend">
                <button class="btn btn-info" type="button" (click)="changeQty(itm.pid,1,'')">+</button>
              </div>
              <input type="text" class="form-control text-center" value="{{itm.qty}}" #qtyRef (keyup)="changeQty(itm.pid,qtyRef.value,'replace')" >
              <div class="input-group-append">
                <button class="btn btn-danger" type="button" (click)="changeQty(itm.pid,-1,'')">-</button>
              </div>
            </div>
          </td>
          <td>{{itm.price}}</td>
        </tr>
        </tbody>
    </table>
    <a routerLink = "/billing" class="btn btn-sm btn-primary" *ngIf="cart.cartItemsList && cart.cartTotal">Revisa</a>
  </div>
  <div class="card-footer text-muted font-weight-bold">
    Total : Cop {{cart.cartTotal}}
  </div>  
</div>
  `,
  styles : [`
  .table td {
    vertical-align : unset;
    font-size:14px;
  }
  .w30{
    width: 35%;
  }
  `]
})

export class AddToCartDir{
  
  constructor(
    public cart: CartService
  ){
    
  }

  
  changeQty(pid,qty,replace){
    if(qty !== ''){
      qty=parseInt(qty) || 1;
      this.cart.addToCart(pid,qty,replace);
    }else{
      this.cart.addToCart(pid,1,replace);
    }
    
  }

  emptyCart(){
    let cartStatus = confirm("Are you sure you want to clear the cart ?");
    if(cartStatus){
      this.cart.emptyCart();
      document.location.href = '/products';
    }
  }

}